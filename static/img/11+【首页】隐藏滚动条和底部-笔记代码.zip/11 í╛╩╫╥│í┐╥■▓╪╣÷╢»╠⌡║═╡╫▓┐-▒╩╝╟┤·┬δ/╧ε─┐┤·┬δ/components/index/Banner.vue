<template>
	<view class='banner'>
		<image class='banner-img' src="../../static/img/banner1.jpg" mode=""></image>
	</view>
</template>

<script>
</script>

<style scoped>
.banner{
	width:100%;
	height: 300rpx;
}
.banner-img{
	width:100%;
	height: 300rpx;
}
</style>
